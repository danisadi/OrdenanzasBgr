﻿//using Microsoft.EntityFrameworkCore;
using ProyectoPrincipal.Modelos;
using System;

namespace ProyectoPrincipal.Datos
{
    public class ApplicationDbContext : DbContext
    {
        private readonly string _connectionString;
        public ApplicationDbContext()
        {
            //Se carga la cadena de conexion desde el archivo .env
            _connectionString = Environment.GetEnvironmentVariable("CONNECTION_STRING");

            if (string.IsNullOrEmpty(_connectionString)) 
            {
                throw new InvalidOperationException("La cadena de conexión no esta configurada.");

            }
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //Configuración de conexión a la base de datos
                optionsBuilder.UseSqlServer(_connectionString);
            }
        }
        public DbSet<Producto> Productos { get; set; }
    }
}
