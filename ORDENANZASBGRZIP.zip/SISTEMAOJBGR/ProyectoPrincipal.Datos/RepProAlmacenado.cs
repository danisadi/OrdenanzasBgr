﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ProyectoPrincipal.Datos

{
    public class ReProAlmacenado
    {
        private readonly string _connectionString;
        public ReProAlmacenado(string connectionString)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
        }

        /// <summary> 
        /// Ejecuta un procedimiento almacenado y devuelve los resultados como DataTable. 
        /// </summary> 
        /// <param name="procedureName">Nombre del procedimiento almacenado.</param> 
        /// <param name="parameters">Parámetros para el procedimiento almacenado.</param> 
        /// <returns>DataTable con los resultados del procedimiento almacenado.</returns> 

        public DataTable ExecuteStoredProcedure(string procedureName, SqlParameter[] parameters = null)
        {
            // Validar que se proporcione el nombre del procedimiento almacenado 
            if (string.IsNullOrWhiteSpace(procedureName))
            {
                throw new ArgumentException("El nombre del procedimiento almacenado no puede ser nulo o vacío.", nameof(procedureName));
            }

            // Crear un DataTable para almacenar los resultados 
            var dataTable = new DataTable();
            try
            {
                // Usar SqlConnection para conectarse a la base de datos 
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    // Crear SqlCommand para ejecutar el procedimiento almacenado 
                    using (var command = new SqlCommand(procedureName, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        // Si se proporcionan parámetros, agregarlos al comando 
                        if (parameters != null)
                        {
                            command.Parameters.AddRange(parameters);
                        }

                        // Usar SqlDataAdapter para llenar el DataTable con los resultados 
                        using (var adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(dataTable);

                        }
                    }
                    connection.Close();
                }

            }
            catch (Exception ex)
            {
                // Manejo de errores: lanzar la excepción para que pueda ser capturada en niveles superiores 
                throw new Exception($"Error al ejecutar el procedimiento almacenado '{procedureName}': {ex.Message}", ex);
            }
            return dataTable;

        }

    }

}