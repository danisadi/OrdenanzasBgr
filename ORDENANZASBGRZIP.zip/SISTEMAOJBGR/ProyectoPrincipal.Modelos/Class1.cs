﻿namespace ProyectoPrincipal.Modelos
{
    public class Class1
    {

    }
}
