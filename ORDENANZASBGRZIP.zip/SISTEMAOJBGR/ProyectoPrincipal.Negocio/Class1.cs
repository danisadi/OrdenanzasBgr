﻿namespace ProyectoPrincipal.Negocio
{
    public class Class1
    {

    }
}
