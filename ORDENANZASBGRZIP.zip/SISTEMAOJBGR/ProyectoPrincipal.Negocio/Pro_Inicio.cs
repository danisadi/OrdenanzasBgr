﻿using System.Data;
using ProyectoPrincipal.Datos;
using System.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ProyectoPrincipal.Negocio
{
    public class Pro_Inicio
    {
        private readonly ReProAlmacenado _repository;

        public Pro_Inicio(ReProAlmacenado repository)
        {
            _repository = repository;
        }

        public DataTable ObtenerProcesos(string nombre, string idProceso)
        {
            string procedimiento = "cargarEstructuraArchivo";
            SqlParameter[] param = new SqlParameter[]
            {
                new SqlParameter("@nombreArchivo", SqlDbType.Text) { Value = nombre},
                new SqlParameter("@idProceso", SqlDbType.Text) { Value =idProceso}
            };
            return _repository.ExecuteStoredProcedure(procedimiento, param);
        }
    }
}
