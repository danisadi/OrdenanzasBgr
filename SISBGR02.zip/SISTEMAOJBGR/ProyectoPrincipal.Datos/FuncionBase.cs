﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProyectoPrincipal.Datos;

namespace ProyectoPrincipal.Datos
{
    public class FuncionBase
    {
        private readonly string _conexionDb;

        public FuncionBase()
        {
            _conexionDb = Environment.GetEnvironmentVariable("CONNECTION_STRING");
        }

        public string GetConexionDb()
        {
            return _conexionDb;
        }
        
    }
}
