﻿////using Microsoft.AspNetCore.Http;
////using Microsoft.AspNetCore.Mvc;

//// Instalar el paquete Microsoft.AspNetCore.Http.Abstract


//namespace ProyectoPrincipal.Modelos
//{
//    public class Class1
//    {
//        public iFormFile archivo1 { get; set; }
//    }
//}
